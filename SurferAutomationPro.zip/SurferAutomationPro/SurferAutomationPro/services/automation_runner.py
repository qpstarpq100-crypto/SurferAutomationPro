
from core.surfer_controller import SurferController
from core.grid_engine import GridEngine

class AutomationRunner:

    def run(self,dat):

        surfer = SurferController()

        grid = GridEngine(surfer)

        grid.run_grid(dat)

        surfer.quit()
