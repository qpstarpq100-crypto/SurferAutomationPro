
import pythoncom
import win32com.client

class SurferController:

    def __init__(self):
        pythoncom.CoInitialize()
        self.app = win32com.client.Dispatch("Surfer.Application")
        self.app.Visible = True

    def quit(self):
        self.app.Quit()
