
class GridEngine:

    def __init__(self, surfer):
        self.surfer = surfer

    def run_grid(self, dat):

        grd = dat.replace(".dat",".grd")

        self.surfer.app.GridData(
            DataFile=dat,
            OutGrid=grd,
            Algorithm=2
        )

        print("Grid created:",grd)
