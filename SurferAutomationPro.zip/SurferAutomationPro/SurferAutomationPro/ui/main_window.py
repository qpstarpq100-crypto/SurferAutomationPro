
import tkinter as tk
from tkinter import ttk,filedialog
from services.automation_runner import AutomationRunner

class MainWindow:

    def __init__(self,root):

        root.title("Surfer Automation Pro")
        root.geometry("900x600")

        frame = ttk.Frame(root)
        frame.pack(padx=20,pady=20)

        ttk.Label(frame,text="DAT file").grid(row=0,column=0)

        self.entry = ttk.Entry(frame,width=50)
        self.entry.grid(row=0,column=1)

        ttk.Button(frame,text="Browse",command=self.select).grid(row=0,column=2)

        ttk.Button(frame,text="Run Automation",command=self.run).grid(row=1,column=1,pady=20)

    def select(self):

        file = filedialog.askopenfilename(filetypes=[("DAT","*.dat")])

        self.entry.delete(0,"end")
        self.entry.insert(0,file)

    def run(self):

        dat = self.entry.get()

        runner = AutomationRunner()

        runner.run(dat)
