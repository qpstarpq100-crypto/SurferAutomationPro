import numpy as np
from numpy.fft import fft2, ifft2, fftshift


class GeophysicalTools:

    def __init__(self, logger):

        self.logger = logger

    # -------------------------

    def fft_spectrum(self, grid):

        spectrum = fftshift(fft2(grid))

        self.logger.log("FFT spectrum calculated")

        return np.abs(spectrum)

    # -------------------------

    def upward_continuation(self, grid, height):

        rows, cols = grid.shape

        fx = np.fft.fftfreq(cols)
        fy = np.fft.fftfreq(rows)

        kx, ky = np.meshgrid(fx, fy)

        k = np.sqrt(kx**2 + ky**2)

        F = fft2(grid)

        continuation = F * np.exp(-2 * np.pi * k * height)

        result = np.real(ifft2(continuation))

        self.logger.log("Upward continuation applied")

        return result

    # -------------------------

    def downward_continuation(self, grid, height):

        rows, cols = grid.shape

        fx = np.fft.fftfreq(cols)
        fy = np.fft.fftfreq(rows)

        kx, ky = np.meshgrid(fx, fy)

        k = np.sqrt(kx**2 + ky**2)

        F = fft2(grid)

        continuation = F * np.exp(2 * np.pi * k * height)

        result = np.real(ifft2(continuation))

        self.logger.log("Downward continuation applied")

        return result

    # -------------------------

    def vertical_derivative(self, grid):

        F = fft2(grid)

        rows, cols = grid.shape

        fx = np.fft.fftfreq(cols)
        fy = np.fft.fftfreq(rows)

        kx, ky = np.meshgrid(fx, fy)

        k = np.sqrt(kx**2 + ky**2)

        result = np.real(ifft2(F * (2 * np.pi * k)))

        self.logger.log("Vertical derivative calculated")

        return result

    # -------------------------

    def horizontal_gradient(self, grid):

        gx, gy = np.gradient(grid)

        gradient = np.sqrt(gx**2 + gy**2)

        self.logger.log("Horizontal gradient calculated")

        return gradient