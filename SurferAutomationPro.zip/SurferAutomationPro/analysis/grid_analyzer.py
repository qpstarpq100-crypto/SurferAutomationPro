import numpy as np


class GridAnalyzer:

    def __init__(self, logger):

        self.logger = logger

    def gradient(self, grid):

        gx, gy = np.gradient(grid)

        magnitude = np.sqrt(gx**2 + gy**2)

        self.logger.log("Gradient calculated")

        return magnitude

    def slope(self, grid):

        gx, gy = np.gradient(grid)

        slope = np.sqrt(gx**2 + gy**2)

        self.logger.log("Slope calculated")

        return slope

    def aspect(self, grid):

        gx, gy = np.gradient(grid)

        aspect = np.arctan2(gy, gx)

        self.logger.log("Aspect calculated")

        return aspect

    def laplacian(self, grid):

        gx, gy = np.gradient(grid)

        gxx, _ = np.gradient(gx)
        _, gyy = np.gradient(gy)

        lap = gxx + gyy

        self.logger.log("Laplacian calculated")

        return lap

    def statistics(self, grid):

        stats = {

            "min": float(np.min(grid)),
            "max": float(np.max(grid)),
            "mean": float(np.mean(grid)),
            "std": float(np.std(grid))
        }

        self.logger.log("Statistics calculated")

        return stats