class PluginInterface:

    name = "BasePlugin"

    def run(self, controller, grid):

        raise NotImplementedError(
            "Plugin must implement run()"
        )