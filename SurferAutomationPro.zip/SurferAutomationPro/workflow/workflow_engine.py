from workflow.workflow_steps import WorkflowSteps


class WorkflowEngine:

    def __init__(self, controller, logger):

        self.controller = controller
        self.logger = logger

        self.steps = WorkflowSteps(
            controller,
            logger
        )

    def run(self, config):

        self.logger.log("Workflow started")

        self.controller.start()

        grid = self.steps.run_data(config)

        grid = self.steps.run_calculus(
            grid,
            config
        )

        grid = self.steps.run_filters(
            grid,
            config
        )

        self.steps.run_maps(
            grid,
            config
        )

        self.logger.log("Workflow finished")