from surfer.surfer_griddata import GridDataRunner
from surfer.surfer_calculus import CalculusRunner
from surfer.surfer_filters import FilterRunner
from surfer.surfer_maps import MapRunner


class WorkflowSteps:

    def __init__(self, controller, logger):

        self.controller = controller
        self.logger = logger

        self.grid_runner = GridDataRunner(controller)
        self.calculus_runner = CalculusRunner(controller)
        self.filter_runner = FilterRunner(controller)
        self.map_runner = MapRunner(controller)

    def run_data(self, config):

        grid = "output.grd"

        return self.grid_runner.run(
            config.data_file,
            grid,
            config.x_col,
            config.y_col,
            config.z_col,
            config.algorithm
        )

    def run_calculus(self, grid, config):

        if config.calculus_enabled:

            grid = self.calculus_runner.run(
                grid,
                config.calculus_type
            )

        return grid

    def run_filters(self, grid, config):

        if config.filter_enabled:

            grid = self.filter_runner.run(
                grid,
                config.filter_name
            )

        return grid

    def run_maps(self, grid, config):

        self.map_runner.run(
            grid,
            config
        )