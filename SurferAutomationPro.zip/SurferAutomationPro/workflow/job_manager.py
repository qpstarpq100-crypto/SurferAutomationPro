from PyQt6.QtCore import QThread, pyqtSignal


class JobWorker(QThread):

    progress = pyqtSignal(int)
    finished = pyqtSignal()

    def __init__(self, workflow, config_list):

        super().__init__()

        self.workflow = workflow
        self.config_list = config_list

        self.running = True

    def run(self):

        total = len(self.config_list)

        for i, config in enumerate(self.config_list):

            if not self.running:
                break

            self.workflow.run(config)

            percent = int((i + 1) / total * 100)

            self.progress.emit(percent)

        self.finished.emit()

    def stop(self):

        self.running = False