from core.surfer_controller import SurferController
from core.grid_engine import GridEngine


class AutomationRunner:

    def __init__(self):

        self.surfer = SurferController()

        self.grid = GridEngine(self.surfer)

    def run(self, dat_file, grd_file):

        print("Grid process started")

        ok = self.grid.run_grid(dat_file, grd_file)

        if ok:

            print("Grid oluşturuldu")

        else:

            print("Grid hatası")

        self.surfer.close()