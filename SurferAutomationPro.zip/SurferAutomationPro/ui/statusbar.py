from tkinter import ttk


class StatusBar:

    def __init__(self, root):

        bar = ttk.Frame(root)

        bar.pack(fill="x")

        self.label = ttk.Label(bar, text="Ready")

        self.label.pack(side="left")

        self.progress = ttk.Progressbar(bar)

        self.progress.pack(side="right")