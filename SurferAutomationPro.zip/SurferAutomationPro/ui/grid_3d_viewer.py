import numpy as np

from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout
)

from PyQt6.QtOpenGLWidgets import QOpenGLWidget

from OpenGL.GL import *
from OpenGL.GLU import *


class Grid3DWidget(QOpenGLWidget):

    def __init__(self, grid=None):

        super().__init__()

        self.grid = grid

        self.rot_x = 30
        self.rot_y = -45
        self.zoom = -100

    def initializeGL(self):

        glEnable(GL_DEPTH_TEST)
        glEnable(GL_COLOR_MATERIAL)

        glClearColor(0.1, 0.1, 0.15, 1)

    def resizeGL(self, w, h):

        glViewport(0, 0, w, h)

        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()

        gluPerspective(45, w / h if h else 1, 0.1, 1000)

        glMatrixMode(GL_MODELVIEW)

    def paintGL(self):

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        glLoadIdentity()

        glTranslatef(0, 0, self.zoom)

        glRotatef(self.rot_x, 1, 0, 0)
        glRotatef(self.rot_y, 0, 1, 0)

        if self.grid is None:
            return

        rows, cols = self.grid.shape

        scale = 1.0

        for i in range(rows - 1):

            glBegin(GL_TRIANGLE_STRIP)

            for j in range(cols):

                z1 = self.grid[i][j] * scale
                z2 = self.grid[i + 1][j] * scale

                glColor3f(0.3, 0.7, 1)

                glVertex3f(i, j, z1)
                glVertex3f(i + 1, j, z2)

            glEnd()

    def mouseMoveEvent(self, event):

        self.rot_x += event.pos().y() * 0.05
        self.rot_y += event.pos().x() * 0.05

        self.update()

    def wheelEvent(self, event):

        self.zoom += event.angleDelta().y() * 0.01

        self.update()


class Grid3DViewer(QDialog):

    def __init__(self, grid):

        super().__init__()

        self.setWindowTitle("3D Grid Viewer")

        layout = QVBoxLayout()

        self.viewer = Grid3DWidget(grid)

        layout.addWidget(self.viewer)

        self.setLayout(layout)