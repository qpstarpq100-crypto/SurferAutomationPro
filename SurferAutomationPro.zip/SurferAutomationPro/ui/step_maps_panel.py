from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QCheckBox,
    QPushButton
)

from ui.map_style_editor import MapStyleEditor


class StepMapsPanel(QGroupBox):

    def __init__(self):

        super().__init__("6. Maps")

        layout = QVBoxLayout()

        # Map selections
        self.contour_checkbox = QCheckBox("Contour Map")
        self.surface_checkbox = QCheckBox("3D Surface")
        self.color_relief_checkbox = QCheckBox("Color Relief")

        layout.addWidget(self.contour_checkbox)
        layout.addWidget(self.surface_checkbox)
        layout.addWidget(self.color_relief_checkbox)

        # Map style editor button
        self.style_button = QPushButton("Map Style Editor")

        layout.addWidget(self.style_button)

        self.setLayout(layout)

        # Default style parameters
        self.map_style = {

            "contour_interval": 0.0,

            "palette": "Rainbow",

            "surface_shading": False,

            "hillshade": False,

            "lighting": False,

            "exaggeration": 1.0
        }

        # Button connection
        self.style_button.clicked.connect(
            self.open_style_editor
        )

    def open_style_editor(self):

        dialog = MapStyleEditor()

        if dialog.exec():

            self.map_style = dialog.get_parameters()

    def get_parameters(self):

        return {

            "contour": self.contour_checkbox.isChecked(),

            "surface": self.surface_checkbox.isChecked(),

            "color_relief": self.color_relief_checkbox.isChecked(),

            "style": self.map_style
        }