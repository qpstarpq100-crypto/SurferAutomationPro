import tkinter as tk
from tkinter import ttk

from ui.sidebar import Sidebar
from ui.header import Header
from ui.statusbar import StatusBar


class MainWindow:

    def __init__(self, root):

        self.root = root

        root.title("Surfer Automation Pro")

        root.geometry("1200x800")

        self.build_ui()

    def build_ui(self):

        Header(self.root)

        body = ttk.Frame(self.root)
        body.pack(fill="both", expand=True)

        Sidebar(body)

        content = ttk.Frame(body)
        content.pack(side="right", fill="both", expand=True)

        StatusBar(self.root)