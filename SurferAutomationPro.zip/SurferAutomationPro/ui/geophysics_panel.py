from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QPushButton
)


class GeophysicsPanel(QGroupBox):

    def __init__(self):

        super().__init__("Geophysical Tools")

        layout = QVBoxLayout()

        self.fft_button = QPushButton("FFT Spectrum")
        self.up_button = QPushButton("Upward Continuation")
        self.down_button = QPushButton("Downward Continuation")
        self.vert_button = QPushButton("Vertical Derivative")
        self.grad_button = QPushButton("Horizontal Gradient")

        layout.addWidget(self.fft_button)
        layout.addWidget(self.up_button)
        layout.addWidget(self.down_button)
        layout.addWidget(self.vert_button)
        layout.addWidget(self.grad_button)

        self.setLayout(layout)