import numpy as np

from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QPushButton
)

from ui.grid_3d_viewer import Grid3DViewer


class Grid3DPanel(QGroupBox):

    def __init__(self):

        super().__init__("3D Viewer")

        layout = QVBoxLayout()

        self.open_button = QPushButton("Open 3D Viewer")

        layout.addWidget(self.open_button)

        self.setLayout(layout)

        self.grid = None

        self.open_button.clicked.connect(self.open_viewer)

    def set_grid(self, grid):

        self.grid = grid

    def open_viewer(self):

        if self.grid is None:
            return

        viewer = Grid3DViewer(self.grid)

        viewer.exec()