from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QLabel,
    QComboBox,
    QDoubleSpinBox,
    QPushButton,
    QFormLayout,
)


class KrigingVariogramEditor(QDialog):

    def __init__(self):

        super().__init__()

        self.setWindowTitle("Variogram Editor")

        self.resize(400, 300)

        layout = QVBoxLayout()

        form = QFormLayout()

        # Variogram Model
        self.model_combo = QComboBox()

        self.model_combo.addItems([
            "Linear",
            "Spherical",
            "Exponential",
            "Gaussian",
            "Power"
        ])

        # Nugget
        self.nugget = QDoubleSpinBox()
        self.nugget.setRange(0, 100000)
        self.nugget.setDecimals(4)

        # Sill
        self.sill = QDoubleSpinBox()
        self.sill.setRange(0, 100000)
        self.sill.setDecimals(4)

        # Range
        self.range = QDoubleSpinBox()
        self.range.setRange(0, 100000)
        self.range.setDecimals(4)

        form.addRow("Model", self.model_combo)
        form.addRow("Nugget", self.nugget)
        form.addRow("Sill", self.sill)
        form.addRow("Range", self.range)

        layout.addLayout(form)

        self.apply_button = QPushButton("Apply")

        layout.addWidget(self.apply_button)

        self.setLayout(layout)

    def get_parameters(self):

        return {

            "model": self.model_combo.currentText(),

            "nugget": self.nugget.value(),

            "sill": self.sill.value(),

            "range": self.range.value(),
        }