from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QFormLayout,
    QDoubleSpinBox,
    QSpinBox,
    QComboBox,
    QPushButton
)


class SurferParameterEditor(QDialog):

    def __init__(self):

        super().__init__()

        self.setWindowTitle("Surfer Parameter Editor")
        self.resize(400, 350)

        layout = QVBoxLayout()

        form = QFormLayout()

        # Cell Size
        self.cell_size = QDoubleSpinBox()
        self.cell_size.setRange(0.0001, 10000)
        self.cell_size.setDecimals(4)

        # Search ellipse angle
        self.search_angle = QDoubleSpinBox()
        self.search_angle.setRange(0, 360)

        # Anisotropy ratio
        self.anisotropy_ratio = QDoubleSpinBox()
        self.anisotropy_ratio.setRange(0.01, 100)

        # Sector search
        self.sectors = QSpinBox()
        self.sectors.setRange(1, 16)

        # Max data
        self.max_data = QSpinBox()
        self.max_data.setRange(1, 500)

        # Min data
        self.min_data = QSpinBox()
        self.min_data.setRange(1, 100)

        # Blank handling
        self.blank_mode = QComboBox()
        self.blank_mode.addItems([
            "LeaveBlank",
            "FillWithZero",
            "FillWithMean"
        ])

        form.addRow("Cell Size", self.cell_size)
        form.addRow("Search Angle", self.search_angle)
        form.addRow("Anisotropy Ratio", self.anisotropy_ratio)
        form.addRow("Sector Search", self.sectors)
        form.addRow("Max Data", self.max_data)
        form.addRow("Min Data", self.min_data)
        form.addRow("Blank Mode", self.blank_mode)

        layout.addLayout(form)

        self.apply_button = QPushButton("Apply")

        layout.addWidget(self.apply_button)

        self.setLayout(layout)

    def get_parameters(self):

        return {

            "cell_size": self.cell_size.value(),

            "search_angle": self.search_angle.value(),

            "anisotropy_ratio": self.anisotropy_ratio.value(),

            "sectors": self.sectors.value(),

            "max_data": self.max_data.value(),

            "min_data": self.min_data.value(),

            "blank_mode": self.blank_mode.currentText()
        }