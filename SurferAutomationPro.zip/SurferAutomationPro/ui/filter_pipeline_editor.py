from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QListWidget,
    QPushButton,
    QLabel,
    QComboBox,
    QWidget,
)


class FilterPipelineEditor(QDialog):

    def __init__(self):

        super().__init__()

        self.setWindowTitle("Filter Pipeline Editor")
        self.resize(500, 400)

        layout = QVBoxLayout()

        layout.addWidget(QLabel("Filter Pipeline"))

        # Pipeline list
        self.pipeline_list = QListWidget()

        layout.addWidget(self.pipeline_list)

        # Filter selection
        filter_row = QHBoxLayout()

        self.filter_combo = QComboBox()

        self.filter_combo.addItems([
            "Minimum",
            "Median",
            "Maximum",
            "Range",
            "StandardDeviation",
            "Variance",
            "ThresholdAveraging"
        ])

        self.add_button = QPushButton("Add Filter")

        filter_row.addWidget(self.filter_combo)
        filter_row.addWidget(self.add_button)

        layout.addLayout(filter_row)

        # Control buttons
        control_row = QHBoxLayout()

        self.remove_button = QPushButton("Remove")
        self.move_up_button = QPushButton("Move Up")
        self.move_down_button = QPushButton("Move Down")

        control_row.addWidget(self.remove_button)
        control_row.addWidget(self.move_up_button)
        control_row.addWidget(self.move_down_button)

        layout.addLayout(control_row)

        # Apply
        self.apply_button = QPushButton("Apply")

        layout.addWidget(self.apply_button)

        self.setLayout(layout)

        # Connections
        self.add_button.clicked.connect(self.add_filter)
        self.remove_button.clicked.connect(self.remove_filter)
        self.move_up_button.clicked.connect(self.move_up)
        self.move_down_button.clicked.connect(self.move_down)

    def add_filter(self):

        filter_name = self.filter_combo.currentText()

        self.pipeline_list.addItem(filter_name)

    def remove_filter(self):

        row = self.pipeline_list.currentRow()

        if row >= 0:
            self.pipeline_list.takeItem(row)

    def move_up(self):

        row = self.pipeline_list.currentRow()

        if row > 0:

            item = self.pipeline_list.takeItem(row)

            self.pipeline_list.insertItem(row - 1, item)

            self.pipeline_list.setCurrentRow(row - 1)

    def move_down(self):

        row = self.pipeline_list.currentRow()

        if row < self.pipeline_list.count() - 1:

            item = self.pipeline_list.takeItem(row)

            self.pipeline_list.insertItem(row + 1, item)

            self.pipeline_list.setCurrentRow(row + 1)

    def get_pipeline(self):

        pipeline = []

        for i in range(self.pipeline_list.count()):

            pipeline.append(
                self.pipeline_list.item(i).text()
            )

        return pipeline