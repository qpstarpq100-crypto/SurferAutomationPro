from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QLabel,
    QSpinBox,
    QPushButton
)

from ui.surfer_parameter_editor import SurferParameterEditor


class StepOptionsPanel(QGroupBox):

    def __init__(self):

        super().__init__("3. Options")

        layout = QVBoxLayout()

        # Sector Search
        layout.addWidget(QLabel("Search Sectors"))

        self.sectors_spin = QSpinBox()
        self.sectors_spin.setRange(1, 16)

        layout.addWidget(self.sectors_spin)

        # Advanced parameters button
        self.parameter_button = QPushButton("Advanced Parameters")

        layout.addWidget(self.parameter_button)

        self.setLayout(layout)

        # Default parameters
        self.parameters = {

            "cell_size": 1.0,
            "search_angle": 0.0,
            "anisotropy_ratio": 1.0,
            "sectors": 4,
            "max_data": 64,
            "min_data": 8,
            "blank_mode": "LeaveBlank"
        }

        # Button connection
        self.parameter_button.clicked.connect(
            self.open_parameter_editor
        )

    def open_parameter_editor(self):

        dialog = SurferParameterEditor()

        if dialog.exec():

            self.parameters = dialog.get_parameters()

    def get_parameters(self):

        return {

            "sectors": self.sectors_spin.value(),

            "advanced": self.parameters
        }