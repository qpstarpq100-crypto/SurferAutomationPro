import tkinter as tk


class Sidebar:

    def __init__(self, parent):

        frame = tk.Frame(parent, width=200, bg="#2c3e50")

        frame.pack(side="left", fill="y")

        steps = [
            "Data",
            "Filter",
            "Options",
            "Cross Validation",
            "Grid",
            "Map",
            "Run"
        ]

        for s in steps:

            b = tk.Label(
                frame,
                text=s,
                bg="#2c3e50",
                fg="white",
                pady=10
            )

            b.pack(fill="x")