from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QListWidget,
    QPushButton,
    QLabel
)


class MapWorkspace(QGroupBox):

    def __init__(self):

        super().__init__("Interactive Map Workspace")

        layout = QVBoxLayout()

        self.info = QLabel("Map Layers")

        self.layer_list = QListWidget()

        self.add_layer_button = QPushButton("Add Layer")
        self.remove_layer_button = QPushButton("Remove Layer")

        layout.addWidget(self.info)
        layout.addWidget(self.layer_list)
        layout.addWidget(self.add_layer_button)
        layout.addWidget(self.remove_layer_button)

        self.setLayout(layout)

        self.layers = []

        self.add_layer_button.clicked.connect(self.add_layer)
        self.remove_layer_button.clicked.connect(self.remove_layer)

    def add_layer(self):

        name = f"Layer {len(self.layers)+1}"

        self.layers.append(name)

        self.layer_list.addItem(name)

    def remove_layer(self):

        row = self.layer_list.currentRow()

        if row >= 0:

            self.layers.pop(row)

            self.layer_list.takeItem(row)

    def get_layers(self):

        return self.layers