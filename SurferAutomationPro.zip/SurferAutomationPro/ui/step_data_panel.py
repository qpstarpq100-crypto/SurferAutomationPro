from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
)


class StepDataPanel(QGroupBox):

    def __init__(self):

        super().__init__("1. Data")

        layout = QVBoxLayout()

        row = QHBoxLayout()

        self.file_edit = QLineEdit()

        self.browse_button = QPushButton("Browse")

        row.addWidget(QLabel("Data File"))
        row.addWidget(self.file_edit)
        row.addWidget(self.browse_button)

        layout.addLayout(row)

        self.setLayout(layout)