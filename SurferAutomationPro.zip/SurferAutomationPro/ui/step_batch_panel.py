from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QFileDialog
)


class StepBatchPanel(QGroupBox):

    def __init__(self):

        super().__init__("7. Batch Processing")

        layout = QVBoxLayout()

        layout.addWidget(QLabel("DAT Folder"))

        self.folder_edit = QLineEdit()

        layout.addWidget(self.folder_edit)

        self.browse_button = QPushButton(
            "Browse"
        )

        layout.addWidget(self.browse_button)

        self.setLayout(layout)

        self.browse_button.clicked.connect(
            self.browse_folder
        )

    def browse_folder(self):

        folder = QFileDialog.getExistingDirectory(
            self,
            "Select DAT Folder"
        )

        if folder:

            self.folder_edit.setText(folder)

    def get_parameters(self):

        return {

            "folder": self.folder_edit.text()

        }