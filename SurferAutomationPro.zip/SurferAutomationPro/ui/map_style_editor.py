from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QFormLayout,
    QDoubleSpinBox,
    QComboBox,
    QCheckBox,
    QPushButton
)


class MapStyleEditor(QDialog):

    def __init__(self):

        super().__init__()

        self.setWindowTitle("Map Style Editor")
        self.resize(400, 350)

        layout = QVBoxLayout()

        form = QFormLayout()

        # Contour interval
        self.contour_interval = QDoubleSpinBox()
        self.contour_interval.setRange(0.0001, 100000)
        self.contour_interval.setDecimals(4)

        # Color palette
        self.palette = QComboBox()
        self.palette.addItems([
            "Rainbow",
            "Terrain",
            "Grayscale",
            "Heatmap",
            "Topo"
        ])

        # Surface shading
        self.surface_shading = QCheckBox()

        # Hillshade
        self.hillshade = QCheckBox()

        # Lighting
        self.lighting = QCheckBox()

        # Vertical exaggeration
        self.exaggeration = QDoubleSpinBox()
        self.exaggeration.setRange(0.1, 100)
        self.exaggeration.setValue(1.0)

        form.addRow("Contour Interval", self.contour_interval)
        form.addRow("Color Palette", self.palette)
        form.addRow("Surface Shading", self.surface_shading)
        form.addRow("Hillshade", self.hillshade)
        form.addRow("Lighting", self.lighting)
        form.addRow("Vertical Exaggeration", self.exaggeration)

        layout.addLayout(form)

        self.apply_button = QPushButton("Apply")

        layout.addWidget(self.apply_button)

        self.setLayout(layout)

    def get_parameters(self):

        return {

            "contour_interval": self.contour_interval.value(),

            "palette": self.palette.currentText(),

            "surface_shading": self.surface_shading.isChecked(),

            "hillshade": self.hillshade.isChecked(),

            "lighting": self.lighting.isChecked(),

            "exaggeration": self.exaggeration.value()
        }