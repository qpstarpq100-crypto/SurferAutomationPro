from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QCheckBox,
)


class StepCalculusPanel(QGroupBox):

    def __init__(self):

        super().__init__("4. Calculus")

        layout = QVBoxLayout()

        self.first_derivative = QCheckBox("First Derivative")

        self.laplacian = QCheckBox("Laplacian")

        layout.addWidget(self.first_derivative)
        layout.addWidget(self.laplacian)

        self.setLayout(layout)