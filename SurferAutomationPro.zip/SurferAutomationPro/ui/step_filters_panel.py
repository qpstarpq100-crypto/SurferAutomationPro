from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QListWidget,
)

from ui.filter_pipeline_editor import FilterPipelineEditor


class StepFiltersPanel(QGroupBox):

    def __init__(self):

        super().__init__("5. Filters")

        layout = QVBoxLayout()

        # Label
        layout.addWidget(QLabel("Filter Pipeline"))

        # Pipeline list
        self.pipeline_list = QListWidget()

        layout.addWidget(self.pipeline_list)

        # Pipeline editor button
        self.pipeline_button = QPushButton("Pipeline Editor")

        layout.addWidget(self.pipeline_button)

        self.setLayout(layout)

        # Pipeline data
        self.pipeline = []

        # Button connection
        self.pipeline_button.clicked.connect(self.open_pipeline_editor)

    def open_pipeline_editor(self):

        dialog = FilterPipelineEditor()

        if dialog.exec():

            self.pipeline = dialog.get_pipeline()

            self.update_pipeline_view()

    def update_pipeline_view(self):

        self.pipeline_list.clear()

        for f in self.pipeline:

            self.pipeline_list.addItem(f)

    def get_parameters(self):

        return {

            "pipeline": self.pipeline

        }