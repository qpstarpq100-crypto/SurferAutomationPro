from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QPushButton,
    QProgressBar
)


class JobManagerPanel(QGroupBox):

    def __init__(self):

        super().__init__("Job Manager")

        layout = QVBoxLayout()

        self.progress = QProgressBar()

        self.start_button = QPushButton("Start Jobs")

        self.cancel_button = QPushButton("Cancel")

        layout.addWidget(self.progress)
        layout.addWidget(self.start_button)
        layout.addWidget(self.cancel_button)

        self.setLayout(layout)