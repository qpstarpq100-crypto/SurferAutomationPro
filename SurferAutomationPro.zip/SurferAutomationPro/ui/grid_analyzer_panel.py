from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QPushButton,
    QTextEdit
)


class GridAnalyzerPanel(QGroupBox):

    def __init__(self):

        super().__init__("Grid Analyzer")

        layout = QVBoxLayout()

        self.gradient_button = QPushButton("Gradient")
        self.slope_button = QPushButton("Slope")
        self.aspect_button = QPushButton("Aspect")
        self.laplacian_button = QPushButton("Laplacian")
        self.stats_button = QPushButton("Statistics")

        self.output = QTextEdit()

        layout.addWidget(self.gradient_button)
        layout.addWidget(self.slope_button)
        layout.addWidget(self.aspect_button)
        layout.addWidget(self.laplacian_button)
        layout.addWidget(self.stats_button)

        layout.addWidget(self.output)

        self.setLayout(layout)