from PyQt6.QtWidgets import (
    QGroupBox,
    QVBoxLayout,
    QLabel,
    QComboBox,
    QPushButton,
)

from ui.kriging_variogram_editor import KrigingVariogramEditor


class StepKrigingPanel(QGroupBox):

    def __init__(self):

        super().__init__("2. Kriging")

        layout = QVBoxLayout()

        # Grid Algorithm Selection
        self.algorithm_combo = QComboBox()

        self.algorithm_combo.addItems([
            "Kriging",
            "InverseDistance",
            "MinimumCurvature",
            "NaturalNeighbor",
            "NearestNeighbor",
            "Triangulation"
        ])

        layout.addWidget(QLabel("Interpolation Algorithm"))
        layout.addWidget(self.algorithm_combo)

        # Variogram Editor Button
        self.variogram_button = QPushButton("Variogram Editor")

        layout.addWidget(self.variogram_button)

        self.setLayout(layout)

        # Default variogram parameters
        self.variogram_params = {
            "model": "Spherical",
            "nugget": 0.0,
            "sill": 1.0,
            "range": 100.0
        }

        # Connect button
        self.variogram_button.clicked.connect(self.open_variogram)

    def open_variogram(self):

        dialog = KrigingVariogramEditor()

        if dialog.exec():

            self.variogram_params = dialog.get_parameters()

    def get_parameters(self):

        return {

            "algorithm": self.algorithm_combo.currentText(),

            "variogram": self.variogram_params
        }