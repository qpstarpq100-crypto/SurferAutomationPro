from services.automation_runner import AutomationRunner


def run_process(dat):

    runner = AutomationRunner()

    grd = dat.replace(".dat", ".grd")

    runner.run(dat, grd)