from validation.parameter_ranges import PARAM_RANGES


class ParameterValidator:

    def validate(self, name, value):

        if name not in PARAM_RANGES:

            return True

        min_v, max_v = PARAM_RANGES[name]

        if not (min_v <= value <= max_v):

            raise ValueError(
                f"{name} must be between {min_v} and {max_v}"
            )

        return True