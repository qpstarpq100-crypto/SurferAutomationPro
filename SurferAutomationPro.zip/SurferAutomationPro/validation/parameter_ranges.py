PARAM_RANGES = {

    "anisotropy_ratio": (0.01, 100),

    "anisotropy_angle": (0, 360),

    "rows": (3, 25),

    "cols": (3, 25),

    "passes": (1, 50)
}