from dataclasses import dataclass


@dataclass
class AppConfig:

    data_file: str = ""

    x_col: int = 1
    y_col: int = 2
    z_col: int = 3

    algorithm: str = "Kriging"

    anisotropy_ratio: float = 1.0
    anisotropy_angle: float = 0.0

    filter_enabled: bool = False