import json
import os


class ProjectManager:

    def __init__(self, logger):

        self.logger = logger

        self.project_path = None

        self.project_data = {}

    def new_project(self):

        self.project_data = {

            "data_file": "",

            "kriging": {},

            "options": {},

            "calculus": {},

            "filters": {},

            "maps": {}
        }

        self.project_path = None

        self.logger.log("New project created")

    def save_project(self, path):

        if not path:

            raise ValueError("Invalid project path")

        with open(path, "w") as f:

            json.dump(self.project_data, f, indent=4)

        self.project_path = path

        self.logger.log("Project saved")

    def load_project(self, path):

        if not os.path.exists(path):

            raise FileNotFoundError("Project not found")

        with open(path) as f:

            self.project_data = json.load(f)

        self.project_path = path

        self.logger.log("Project loaded")

    def update_section(self, section, data):

        self.project_data[section] = data

    def get_section(self, section):

        return self.project_data.get(section, {})