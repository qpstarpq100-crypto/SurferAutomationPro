import json
import os


class RecentProjects:

    def __init__(self):

        self.file = "recent_projects.json"

    def add(self, path):

        projects = self.load()

        if path not in projects:

            projects.insert(0, path)

        projects = projects[:10]

        with open(self.file, "w") as f:

            json.dump(projects, f)

    def load(self):

        if not os.path.exists(self.file):

            return []

        with open(self.file) as f:

            return json.load(f)