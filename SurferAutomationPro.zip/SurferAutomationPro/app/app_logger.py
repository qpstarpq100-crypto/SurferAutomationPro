import datetime


class AppLogger:

    def __init__(self, callback=None):

        self.callback = callback

    def log(self, message):

        time_str = datetime.datetime.now().strftime("%H:%M:%S")

        msg = f"[{time_str}] {message}"

        if self.callback:
            self.callback(msg)

        print(msg)