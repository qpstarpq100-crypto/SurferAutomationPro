import logging


logging.basicConfig(
    filename="automation.log",
    level=logging.INFO
)


def log(msg):

    logging.info(msg)