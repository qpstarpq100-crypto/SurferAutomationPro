import random


class CrossValidator:

    def __init__(self, data):

        self.data = data

    def random_sample(self, n):

        return random.sample(self.data, n)