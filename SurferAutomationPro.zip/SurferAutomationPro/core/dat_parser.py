class DatParser:

    @staticmethod
    def original_count(file):

        count = 0

        with open(file, "r", encoding="utf8", errors="ignore") as f:

            for line in f:

                if line.strip():

                    count += 1

        return count