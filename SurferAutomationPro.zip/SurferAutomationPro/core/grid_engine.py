import os


class GridEngine:

    def __init__(self, surfer):

        self.surfer = surfer

    def run_grid(self, dat_file):

        grd_file = dat_file.replace(".dat", ".grd")

        try:

            self.surfer.app.GridData(
                DataFile=dat_file,
                OutGrid=grd_file,
                Algorithm=2,
                ShowReport=False
            )

            print("Grid oluşturuldu:", grd_file)

            return grd_file

        except Exception as e:

            print("GridData hata:", e)

            return None