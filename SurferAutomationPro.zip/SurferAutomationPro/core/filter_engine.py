import numpy as np


class FilterEngine:

    @staticmethod
    def median_z(values):

        return np.median(values)