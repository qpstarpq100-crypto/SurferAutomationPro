import pythoncom
import win32com.client


class SurferController:

    def __init__(self):

        try:
            pythoncom.CoInitialize()

            self.app = win32com.client.Dispatch("Surfer.Application")

            self.app.Visible = True

            print("Surfer COM bağlantısı kuruldu")

        except Exception as e:

            raise RuntimeError(f"Surfer başlatılamadı: {e}")

    def quit(self):

        if self.app:
            self.app.Quit()