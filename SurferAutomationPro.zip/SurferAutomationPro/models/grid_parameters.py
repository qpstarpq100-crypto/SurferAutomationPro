from dataclasses import dataclass


@dataclass
class GridParameters:

    data_file: str = ""

    x_col: int = 1
    y_col: int = 2
    z_col: int = 3

    algorithm: str = "Kriging"

    calculus_enabled: bool = False
    calculus_type: str = "FirstDerivative"

    filter_enabled: bool = False
    filter_name: str = "Median"

    map_contour: bool = True
    map_surface: bool = False
    map_color_relief: bool = False