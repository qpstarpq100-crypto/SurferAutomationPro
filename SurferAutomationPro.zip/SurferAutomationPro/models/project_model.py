from dataclasses import dataclass
from models.grid_parameters import GridParameters


@dataclass
class ProjectModel:

    name: str = "Surfer Project"

    parameters: GridParameters = GridParameters()

    last_grid: str = ""