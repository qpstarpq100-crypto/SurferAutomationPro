import os
import zipfile

project_name = "SurferAutomationPro"

files = {

"main.py": '''
import tkinter as tk
from ui.main_window import MainWindow

def main():
    root = tk.Tk()
    MainWindow(root)
    root.mainloop()

if __name__ == "__main__":
    main()
''',

"core/surfer_controller.py": '''
import pythoncom
import win32com.client

class SurferController:

    def __init__(self):
        pythoncom.CoInitialize()
        self.app = win32com.client.Dispatch("Surfer.Application")
        self.app.Visible = True

    def quit(self):
        self.app.Quit()
''',

"core/grid_engine.py": '''
class GridEngine:

    def __init__(self, surfer):
        self.surfer = surfer

    def run_grid(self, dat):

        grd = dat.replace(".dat",".grd")

        self.surfer.app.GridData(
            DataFile=dat,
            OutGrid=grd,
            Algorithm=2
        )

        print("Grid created:",grd)
''',

"services/automation_runner.py": '''
from core.surfer_controller import SurferController
from core.grid_engine import GridEngine

class AutomationRunner:

    def run(self,dat):

        surfer = SurferController()

        grid = GridEngine(surfer)

        grid.run_grid(dat)

        surfer.quit()
''',

"ui/main_window.py": '''
import tkinter as tk
from tkinter import ttk,filedialog
from services.automation_runner import AutomationRunner

class MainWindow:

    def __init__(self,root):

        root.title("Surfer Automation Pro")
        root.geometry("900x600")

        frame = ttk.Frame(root)
        frame.pack(padx=20,pady=20)

        ttk.Label(frame,text="DAT file").grid(row=0,column=0)

        self.entry = ttk.Entry(frame,width=50)
        self.entry.grid(row=0,column=1)

        ttk.Button(frame,text="Browse",command=self.select).grid(row=0,column=2)

        ttk.Button(frame,text="Run Automation",command=self.run).grid(row=1,column=1,pady=20)

    def select(self):

        file = filedialog.askopenfilename(filetypes=[("DAT","*.dat")])

        self.entry.delete(0,"end")
        self.entry.insert(0,file)

    def run(self):

        dat = self.entry.get()

        runner = AutomationRunner()

        runner.run(dat)
'''
}

def create_project():

    os.makedirs(project_name+"/core",exist_ok=True)
    os.makedirs(project_name+"/ui",exist_ok=True)
    os.makedirs(project_name+"/services",exist_ok=True)

    for path,content in files.items():

        full = os.path.join(project_name,path)

        os.makedirs(os.path.dirname(full),exist_ok=True)

        with open(full,"w",encoding="utf8") as f:
            f.write(content)

    zip_name = project_name + ".zip"

    with zipfile.ZipFile(zip_name,"w") as z:

        for root,dirs,fs in os.walk(project_name):
            for f in fs:
                file_path = os.path.join(root,f)
                z.write(file_path)

    print("ZIP created:",zip_name)

create_project()