from core.surfer_controller import SurferController
from core.grid_engine import GridEngine


dat = r"C:\test\data.dat"


surfer = SurferController()

grid = GridEngine(surfer)

grid.run_grid(dat)

surfer.quit()