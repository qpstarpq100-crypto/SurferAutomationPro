class MapRunner:

    def __init__(self, controller):

        self.controller = controller

    def run(self, grid, config):

        doc = self.controller.doc

        if config.map_contour:

            self.controller.logger.log(
                "Creating contour map"
            )

            doc.Shapes.AddContourMap(
                GridFileName=grid
            )

        if config.map_surface:

            self.controller.logger.log(
                "Creating surface map"
            )

            doc.Shapes.AddSurfaceMap(
                GridFileName=grid
            )

        if config.map_color_relief:

            self.controller.logger.log(
                "Creating color relief map"
            )

            doc.Shapes.AddColorReliefMap(
                GridFileName=grid
            )