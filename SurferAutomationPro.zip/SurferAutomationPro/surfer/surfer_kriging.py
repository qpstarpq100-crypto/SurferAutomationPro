class KrigingRunner:

    def __init__(self, controller):

        self.controller = controller

    def run(self, data_file, out_grid, params):

        self.controller.logger.log(
            "Running Kriging"
        )

        self.controller.app.GridData(

            DataFile=data_file,

            Algorithm=2,

            VariogramModel=params["model"],

            Nugget=params["nugget"],

            Sill=params["sill"],

            Range=params["range"],

            OutGrid=out_grid
        )

        return out_grid