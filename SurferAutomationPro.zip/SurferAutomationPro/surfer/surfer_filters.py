FILTER_TYPES = {

    "Minimum": 50,
    "Median": 52,
    "Maximum": 54,
    "Range": 55,
    "StdDev": 56,
    "ThresholdAvg": 60
}


class FilterRunner:

    def __init__(self, controller):

        self.controller = controller

    def run(self, grid, filter_name):

        out_grid = "filter_output.grd"

        filter_enum = FILTER_TYPES.get(filter_name, 52)

        self.controller.logger.log(
            f"Running filter {filter_name}"
        )

        self.controller.app.GridFilter(

            InGrid=grid,
            Filter=filter_enum,
            OutGrid=out_grid
        )

        return out_grid