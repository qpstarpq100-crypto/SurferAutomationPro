import win32com.client


class SurferController:

    def __init__(self, logger):

        self.logger = logger
        self.app = None
        self.doc = None

    def start(self):

        self.logger.log("Starting Surfer")

        self.app = win32com.client.Dispatch("Surfer.Application")

        self.app.Visible = True

        self.doc = self.app.Documents.Add()

    def create_contour(self, grid_file):

        self.logger.log("Creating contour map")

        self.doc.Shapes.AddContourMap(
            GridFileName=grid_file
        )

    def create_surface(self, grid_file):

        self.logger.log("Creating surface map")

        self.doc.Shapes.AddSurfaceMap(
            GridFileName=grid_file
        )

    def create_color_relief(self, grid_file):

        self.logger.log("Creating color relief map")

        self.doc.Shapes.AddColorReliefMap(
            GridFileName=grid_file
        )