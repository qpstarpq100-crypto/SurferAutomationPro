GRID_ALGORITHMS = {

    "Kriging": 2,
    "InverseDistance": 3,
    "MinimumCurvature": 4,
    "NaturalNeighbor": 6,
    "NearestNeighbor": 7,
    "Triangulation": 9
}


class GridDataRunner:

    def __init__(self, controller):

        self.controller = controller

    def run(self, data_file, out_grid, x_col, y_col, z_col, algorithm):

        alg = GRID_ALGORITHMS.get(algorithm, 2)

        self.controller.logger.log(
            f"Running GridData using {algorithm}"
        )

        self.controller.app.GridData(

            DataFile=data_file,
            xCol=x_col,
            yCol=y_col,
            zCol=z_col,
            Algorithm=alg,
            OutGrid=out_grid
        )

        return out_grid