FILTER_MAP = {

    "Minimum": 50,
    "Median": 52,
    "Maximum": 54,
    "Range": 55,
    "StandardDeviation": 56,
    "Variance": 57,
    "ThresholdAveraging": 60,
}


class FilterPipelineRunner:

    def __init__(self, controller):

        self.controller = controller

    def run(self, grid, pipeline):

        current_grid = grid

        for i, filter_name in enumerate(pipeline):

            out_grid = f"pipeline_{i}.grd"

            filter_enum = FILTER_MAP.get(filter_name, 52)

            self.controller.logger.log(
                f"Running filter {filter_name}"
            )

            self.controller.app.GridFilter(

                InGrid=current_grid,
                Filter=filter_enum,
                OutGrid=out_grid
            )

            current_grid = out_grid

        return current_grid