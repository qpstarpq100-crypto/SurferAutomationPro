class CalculusRunner:

    def __init__(self, controller):

        self.controller = controller

    def run(self, grid, calculus_type):

        out_grid = "calculus_output.grd"

        if calculus_type == "FirstDerivative":

            self.controller.logger.log(
                "Running First Derivative"
            )

            self.controller.app.GridCalculus(
                InGrid=grid,
                Function="FirstDerivative",
                OutGrid=out_grid
            )

        elif calculus_type == "Laplacian":

            self.controller.logger.log(
                "Running Laplacian"
            )

            self.controller.app.GridCalculus(
                InGrid=grid,
                Function="Laplacian",
                OutGrid=out_grid
            )

        return out_grid